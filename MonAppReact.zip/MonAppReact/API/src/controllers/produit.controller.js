import Produit from "../models/Produit";

class ProduitController{

    static async create(req,res){
        let status = 200;
        let body = {};

        try {
            let produit = await Produit.create({
                nom_prod: req.body.nom_prod,
                description_prod: req.body.description_prod,
                prix_prod: req.body.prix_prod
            })
            body = {produit, 'message': 'Produit created'};
        } catch (error) {
            status = 500;
            body = {'message': error.message}
        }
        return res.status(status).json(body);
    }   

    static async details(req,res){
        let status = 200;
        let body = {};

        try {
            let id = req.params.id;
            let produit = await Produit.findById(id);
            body = {produit, 'message':'Produit'};
        } catch (error) {
            status = 500;
            body = {'message': error.message}
        }
        return res.status(status).json(body);
    }

    static async ListProduit(req,res){
        let status = 200;
        let body = {};

        try {
            let produit = await Produit.find();
            body = produit;
        } catch (error) {
            status = 500;
            body = {'message': error.message}
        }
        return res.status(status).json(body);
    }
    
    static async update(req,res){
        let status = 200;
        let body = {};

        try {
            let id = req.params.id;
            let produit = await Produit.findById(id);
            await produit.update(req.body);
            body = {produit, 'message': 'Updated'};
        } catch (error) {
            status = 500;
            body = {'message': error.message}
    }
    return res.status(status).json(body);
    }

    static async delete(req,res){
        let status = 200;
        let body = {};

        try {
            let id = req.params.id;
            await produit.findByIdAndDelete(id);
            body = {produit, 'message': 'Deleted'};
        } catch (error) {
            status = 500;
            body = {'message': error.message}
    }
    return res.status(status).json(body);
    }   
}

    


export default ProduitController;

/**
 * findOne('slug')
 */