import {Router} from 'express';
import UserController from '../controllers/user.controller';
import TypeUtilisateurController from '../controllers/typeUtilisateur.controller';
import ProduitController from '../controllers/produit.controller';

const router = Router();

router.get('/hello', (req, res) => {
    console.log('Hello');
});

//User
router.post('/user', UserController.create);
router.get('/user/:id', UserController.details);
router.put('/listUsers/:id', UserController.update);
router.delete('/user/rang/:id', UserController.delete);
router.get('/user/rang/:id', UserController.showRang);
router.get('/users', UserController.getAllUsers);

//TypeUtilisateur
router.post('/typeutilisateur', TypeUtilisateurController.create);
router.get('/typeutilisateur/:id', TypeUtilisateurController.details);
router.put('/typeutilisateur/:id', TypeUtilisateurController.update);
router.delete('/typeutilisateur/:id', TypeUtilisateurController.delete);

//Produit
router.post('/addProduit', ProduitController.create);
router.get('/listProduit', ProduitController.ListProduit);
router.put('/update/:id', ProduitController.update);
router.get('/catalogue/:id', ProduitController.details);
router.delete('/delete/:id', ProduitController.delete);


//Auth
router.post('/auth', UserController.auth);

export default router;