import {Schema, model} from 'mongoose';

const typeUtilisateurSchema = new Schema({
    _id: {
        type: Number,
        primaryKey: true
    },
    designation: {
        type: String,
        required: true
    },
});

const TypeUtilisateur = model('typeutilisateur', typeUtilisateurSchema);

export default TypeUtilisateur;