import {Schema, model} from 'mongoose';

const produitSchema = new Schema({
    nom_prod: {
        type: String,
        required: true
    },
    description_prod: {
        type: String,
        required: true
    },
    prix_prod: {
        type: Number,
        required: true
    }
});

const Produit = model('Produit', produitSchema);

export default Produit;