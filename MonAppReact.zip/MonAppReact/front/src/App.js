import React, { Component } from 'react';
import { BrowserRouter, Route } from 'react-router-dom';

import './App.css';
import Home from './pages/Home';
import Header from './components/Header';
import Footer from './components/Footer';
import Login from './pages/Login';
import Signup from './pages/signup';
import Catalogue from './pages/Catalogue';
import DetailsProduit from './pages/DetailsProduit';
import ListUsers from './pages/ListUsers';
import ModifUser from './pages/ModifUser';


class App extends Component {
  constructor(props){
    super(props);
  }

  componentWillMount(){
    console.log("Component will mount");
  }

  componentDidMount(){
    console.log("Component did mount");
    console.log(localStorage.getItem('user'));
    if("user" in localStorage){
      console.log('yes');
   } else {
      console.log('no');
   }
  }

  render() {
    return (
      <BrowserRouter>
      <Header />
        <Route path="/" exact component={Home} />
        <Route path="/login" exact component={Login} />
        <Route path="/signup" exact component={Signup} />
        <Route path="/catalogue" exact component={Catalogue} />
        <Route path="/catalogue/:id" exact component={DetailsProduit} />
        <Route path="/listUsers/" exact component={ListUsers} />
        <Route path="/listUsers/:id" exact component={ModifUser} />
        
        <Footer />
      </BrowserRouter>
    );
  }
}

export default App;
