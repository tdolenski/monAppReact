import React, {Component} from 'react';
import UserService from '../services/user.service';
import imgAccueil from '../img/imgAccueil.jpg';
import '../css/style.css';


class Home extends Component{
    constructor(props){
        super(props);
        this.state = {
            title: "E-Foot",
            users: []
        }
    }

    componentWillMount(){
        console.log("Je suis la");
      }
    
      async componentDidMount(){
        let response = await UserService.list();
        if(response.ok){
            // La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                title: "Liste des utilisateurs",
                users : data.users
            });
        }
      }


    render(){
        return(
            <div className="container">
                <h1>Bienvenue sur E-Foot</h1>
                <center>
                <br></br>
                <img className="imgAccueil" src={imgAccueil} />
                <br></br><br></br>
                </center>
            </div>
        )
    }
}

export default Home;