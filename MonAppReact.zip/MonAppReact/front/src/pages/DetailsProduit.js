import React, {Component} from 'react';
import ProduitService from "../services/produit.service";
import maillotPSG from '../img/maillotPSG.jpg';
import cramponNoir from '../img/cramponNoir.jpg';

class DetailsProduit extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: "",
            nom_prod: "",
            description_prod: "",
            prix_prod: ""
        }
    }

    async componentDidMount() {
        let id = this.props.match.params.id;
        let response = await ProduitService.details(id);
        if (response.ok) {
            //La réponse est de type 200
            let data = await response.json();
            this.setState({
                id: data.produit._id,
                nom_prod: data.produit.nom_prod,
                description_prod: data.produit.description_prod,
                prix_prod: data.produit.prix_prod
            });
            
        }
    }

    render() {
        //Image en dur
        let img = this.state.id;
        if (this.state.id === "5de7b427bace572f10cc5929") {
            img = <img src={maillotPSG}  />;
        } else if (this.state.id === "5de9c36f072dca05346b008d") {
            img = <img src={cramponNoir}  />;
        } else{
            img = "";
        }
        return (
            <div className="container">
                <br></br>
                {img}
                <br></br><br></br>
                <div>Nom du produit : {this.state.nom_prod}</div>
                <div>Description du produit : {this.state.description_prod}</div>
                <div>Prix: {this.state.prix_prod} €</div>
                <br></br>
                <button className="btn btn-primary" href="#">Réserver</button>
            
            </div>
        );
    }
}
export default DetailsProduit;

