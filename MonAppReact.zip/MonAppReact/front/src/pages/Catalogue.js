import React, {Component} from 'react';
import Produit from '../components/Produit';
import ProduitService from '../services/produit.service';

class Catalogue extends Component{
    constructor(props){
        super(props);
        this.state = {
            title: "E-Foot",
            produits: []
        }
    }

    componentWillMount(){
        console.log("Je suis la");
      }
    
      async componentDidMount(){
        let response = await ProduitService.listProduit();
        if(response.ok){
            // La réponse est de type 200
            let data = await response.json();
            console.log(data);
            this.setState({
                produits: data
            });
           
        }
      }
      
    render(){
        return(
            <div className="container">
                <h1>Bienvenue sur E-Foot</h1>
                <tbody> </tbody>
                {
                    this.state.produits.map((item, index )=> {
                        return (
                            <Produit key={index} data={item}/>
                        )
                    })
                }                 
            </div>
        )
    }
}

export default Catalogue;