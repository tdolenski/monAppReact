import React, {Component} from 'react';
import UserService from "../services/user.service";

class ModifUser extends Component {
    constructor(props) {
        super(props);
        this.state = {
            id: "",
            prenom: "",
            nom: "",
            email: "",
            password: "",
            msgSuccess: '',
            msgFalse: '',
            pw:''
        }
    }

    async componentDidMount() {
        let id = this.props.match.params.id;
        let response = await UserService.details(id);
        if (response.ok) {
            //La réponse est de type 200
            let data = await response.json();
            this.setState({
                id: data.user._id,
                prenom: data.user.prenom,
                nom: data.user.nom,
                email: data.user.email,
                password: data.user.password
            });
            
        }
    }

    handleChange(e){
        this.setState({
            [e.target.id] : e.target.value,
            success: false,
            pw: false
        })
        console.log(this.Success)
    }

    async submit(e){
        
        e.preventDefault();
        let body = {
            id: this.state.id,
            prenom: this.state.prenom,
            nom: this.state.nom,
            email: this.state.email,
            password: this.state.password
        };
        console.log(this.state.id);
        console.log(body);
        let response = await UserService.update(this.state.id, body);
        let data = await response.json();
        console.log(data);
        if(data.user){
            this.setState({
                success: true,
                msgSuccess: "Modifié avec succès",
                pw: false,
                user: data.user
            }) 
            // window.location.replace('/listUsers');
            // localStorage.setItem('user', data.user.email);
        }else{
            this.setState({
                pw: true,
                msgFalse: "Mot de passe incorrect"
            })       
        }
        this.props.history.push('/listUsers');
    }

    render() { 
        return (
            <div className="container">
                <div className="monForm">
                    <form onSubmit={(e) => this.submit(e)}>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nom</label>
                        <input type="text" class="form-control" id="nom" value={this.state.nom} onChange={(e) => this.handleChange(e)}/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Prenom</label>
                        <input type="text" class="form-control" id="prenom" value={this.state.prenom} onChange={(e) => this.handleChange(e)} />
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email</label>
                        <input type="email" class="form-control" id="email" value={this.state.email} aria-describedby="emailHelp" onChange={(e) => this.handleChange(e)}/>
                    </div>  
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="text" class="form-control" id="password" value={this.state.password} onChange={(e) => this.handleChange(e)} />
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>
        );
    }
}

export default ModifUser;

