import React, { Component } from 'react';
import UserService from '../services/user.service';
import '../css/style.css';


class Signup extends Component{
    constructor(props){
        super(props);
        this.state = {
            user:{},
            Success: false,
            msgSuccess: ''
        }
    }
    // change state

        handleChange(e){
            this.setState({
                [e.target.id] : e.target.value,
                success: false,
            })
            console.log(this.Success)
        }

        async submit(e){
            e.preventDefault();
            let body = {
                prenom: this.state.prenom,
                nom: this.state.nom,
                email: this.state.email,
                password: this.state.password
            };
            let response = await UserService.create(body);
            let data = await response.json();
            if(data){
                console.log(data);
                console.log(data.user)
                this.setState({
                    success: true,
                    msgSuccess: "Inscription effectué avec succès",
                    user: data.user
                })
                this.props.history.push('/login');
            }else{
                console.log('Mot de passe incorrect?');
                this.setState({
                    pw: true,
                    msgFalse: "Mot de passe incorrect"
                })
            }
        }

    render(){
        return(
            <center>
            <div className="monForm">
            <form onSubmit={(e) => this.submit(e)}>
            <div class="form-group">
                <label for="exampleInputEmail1">Nom</label>
                <input type="text" class="form-control" id="nom" placeholder="Enter nom" onChange={(e) => this.handleChange(e)}/>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Prenom</label>
                <input type="text" class="form-control" id="prenom" placeholder="Enter prenom" onChange={(e) => this.handleChange(e)}/>
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Email address</label>
                <input type="email" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter email" onChange={(e) => this.handleChange(e)}/>
            </div>  
            <div class="form-group">
                <label for="exampleInputPassword1">Password</label>
                <input type="text" class="form-control" id="password" placeholder="Password"onChange={(e) => this.handleChange(e)}/>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            { 
                this.state.success ? <p style={{color: 'green', fontWeight: 'bold'}}>{this.state.msgSuccess}</p> : null
            }     
            {
                this.state.pw ?  <p style={{color: 'red', fontWeight: 'bold'}}>{this.state.msgFalse}</p> : null
            }   
            <br></br><br></br>  
            </div>
            </center>
           
        )
    }
}

export default Signup;

