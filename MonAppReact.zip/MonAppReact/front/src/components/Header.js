import React, { Component } from 'react';
import {Link} from 'react-router-dom';
class Header extends Component{
    constructor(props){
        super(props);
    }

    handleChange(e){
      this.setState({
          [e.target.id] : e.target.value,
      })
      console.log(this.Success)
  }
  async submit(e){
    e.preventDefault();
    localStorage.removeItem('user');
    window.location.replace('/login');
    };

    render(){
        return(
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
          <a className="navbar-brand" href="#">E-Foot</a>
          <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li className="nav-item active">
                <Link className="nav-link" to={'/'}>Accueil <span className="sr-only">(current)</span></Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to={'/Catalogue'}>Catalogue</Link>
              </li>
              { ('user' in localStorage) ? 
                <li className="nav-item">
                  <Link className="nav-link" to={'/listUsers'}>Liste des utilisateurs</Link>
                </li>
              : ""}
              <li className="nav-item">
                <a className="nav-link" href="#"></a>
              </li>
            </ul>   
          </div>
          {
            ('user' in localStorage) ? <ul className="navbar-nav">
                <li className="nav-item"> <Link id='deconnexion' className="nav-link" onClick={(e) => this.submit(e)} to ={'/login'}>Déconnexion</Link> </li>
                </ul> : 
                <ul className="navbar-nav">
                  <li className="nav-item"> <Link className="nav-link" to ={'/login'}>Connexion </Link> </li>
                  <li className="nav-item"> <Link className="nav-link" to ={'/signup'}>Inscription </Link> </li> 
                </ul>
          }                 
        </nav>
            )
    }
}

export default Header;
