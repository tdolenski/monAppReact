import React, { Component } from 'react'
import {Link} from 'react-router-dom';

class User extends Component{
    constructor(props){
        super(props);
    }

    componentDidMount(){
        console.log(this.props)
    }

    render(){
        return(
            <div>
                
                {/* <p>{this.props.data.id}</p> */}
                <p> {this.props.data.prenom} </p>
                <p> {this.props.data.nom} </p>
                <p> {this.props.data.email} </p>
                <Link to={`/listUsers/${this.props.data._id}`}>
                    <button className="btn btn-primary">Modifier</button>
                </Link>
                <hr></hr>
            </div>
        )
    }
}

export default User;

