import React, { Component } from 'react';
import {Link} from 'react-router-dom';

class Produit extends Component{
    constructor(props){
        super(props);
    }

    componentDidMount(){
        console.log(this.props);
    }

    render(){
        return(
            <div>
                    <Link to={`/catalogue/${this.props.data._id}`}>
                    <p>{this.props.data.nom_prod}</p>
                    <p> {this.props.data.description_prod} </p>
                    <p> {this.props.data.prix_prod} </p>
                    </Link>
                    <hr></hr>
            </div>
        )
    }
}

export default Produit;

